import streamlit as st
import pandas as pd


_DEFAULT_BG = (
    "<svg xmlns='http://www.w3.org/2000/svg' width='1600' height='900' viewBox='0 0 1600 900'>"
    "<defs><linearGradient id='g' x1='0' y1='0' x2='1' y2='1'><stop offset='0' stop-color='#0b3b4a'/>"
    "<stop offset='0.55' stop-color='#0f766e'/><stop offset='1' stop-color='#1d4e89'/></linearGradient>"
    "<pattern id='p' width='80' height='80' patternUnits='userSpaceOnUse' patternTransform='rotate(30)'>"
    "<path d='M0 40h80M40 0v80' stroke='#ffffff' stroke-opacity='0.06' stroke-width='1.2'/>"
    "<circle cx='40' cy='40' r='3' fill='#ffffff' fill-opacity='0.10'/></pattern></defs>"
    "<rect width='1600' height='900' fill='url(#g)'/><rect width='1600' height='900' fill='url(#p)'/>"
    "<circle cx='1350' cy='160' r='260' fill='#ffffff' fill-opacity='0.05'/>"
    "<circle cx='200' cy='760' r='320' fill='#ffffff' fill-opacity='0.05'/></svg>"
)


def _background_css() -> str:
    """Custom assets/background.(jpg|png|webp) is served as a static file (never embedded in the page on every click);
    without one, the small built-in generated design is used."""
    import shutil
    from pathlib import Path
    base = Path(__file__).resolve().parent
    for ext in ("jpg", "jpeg", "png", "webp"):
        f = base / "assets" / f"background.{ext}"
        try:
            if f.is_file():
                dst = base / "static" / f"background.{ext}"
                if not dst.exists() or dst.stat().st_mtime < f.stat().st_mtime:
                    dst.parent.mkdir(exist_ok=True)
                    shutil.copyfile(f, dst)
                return f"url('app/static/background.{ext}?v={int(f.stat().st_mtime)}')"
        except OSError:
            pass
    return "url(\"data:image/svg+xml;utf8," + _DEFAULT_BG.replace("#", "%23").replace('"', "'") + "\")"


def apply_rtl_style():
    st.markdown(
        """
        <style>
        .stApp { direction: rtl; font-family: "Segoe UI", Tahoma, Arial, sans-serif; }
        .stMarkdown, .stText, label, input, textarea, select, button, p { text-align: right; }
        .stApp::before { content: ""; position: fixed; inset: 0; z-index: -1; pointer-events: none;
            background-image: __BG__; background-size: cover; background-position: center; }
        .stApp { background: transparent; }
        header[data-testid="stHeader"] { background: transparent; }
        .block-container {
            padding-top: 3.2rem; padding-bottom: 2rem; max-width: 1400px;
            background: rgba(255,255,255,0.93); border-radius: 18px; margin-top: 1rem; margin-bottom: 1rem;
            box-shadow: 0 4px 14px rgba(0,0,0,0.18);
        }
        section[data-testid="stSidebar"] { background: rgba(8,40,52,0.97); }
        /* collapsed sidebar must not leak its contents over the page (Streamlit marks it data-collapsed or aria-expanded) */
        section[data-testid="stSidebar"][data-collapsed="true"], section[data-testid="stSidebar"][aria-expanded="false"] {
            visibility: hidden !important; background: transparent !important; box-shadow: none !important; border: none !important; }
        section[data-testid="stSidebar"][data-collapsed="true"] *, section[data-testid="stSidebar"][aria-expanded="false"] * {
            visibility: hidden !important; }
        div[data-testid="stVerticalBlockBorderWrapper"] div[data-testid="stMetric"] { border: none; background: transparent; padding: 0; }
        section[data-testid="stSidebar"] [data-testid="stPopover"] button { background: rgba(255,255,255,0.10) !important; border: 1px solid rgba(255,255,255,0.3) !important; }
        section[data-testid="stSidebar"] { direction: rtl; color: #eaf4f4; }
        section[data-testid="stSidebar"] p, section[data-testid="stSidebar"] span, section[data-testid="stSidebar"] label, section[data-testid="stSidebar"] button, section[data-testid="stSidebar"] summary, section[data-testid="stSidebar"] h2 { text-align: right; color: #eaf4f4 !important; }
        section[data-testid="stSidebar"] .stButton>button {
            background: rgba(255,255,255,0.06); border: 1px solid rgba(255,255,255,0.14); color: #eaf4f4;
        }
        section[data-testid="stSidebar"] .stButton>button:hover { background: rgba(255,255,255,0.18); }
        section[data-testid="stSidebar"] .stButton>button[kind="primary"] { background: #14b8a6; color: #04252b !important; border: none; }
        section[data-testid="stSidebar"] [data-testid="stExpander"] details,
        section[data-testid="stSidebar"] [data-testid="stExpander"] summary { background: transparent !important; border: none !important; }
        section[data-testid="stSidebar"] [data-testid="stExpander"] summary:hover { background: rgba(255,255,255,0.08) !important; }
        .stButton>button, .stDownloadButton>button { width: 100%; border-radius: 10px; font-weight: 600; }
        div[data-testid="stMetric"] {
            background: linear-gradient(135deg,#f8fbfb,#eaf3f3); border: 1px solid #d6e4e6; border-radius: 14px; padding: 10px 14px;
        }
        div[data-testid="stVerticalBlockBorderWrapper"] { border-radius: 14px; }
        div[data-testid="stDialog"] div[role="dialog"] { border-radius: 16px; }
        .small-muted { color: #6b7280; font-size: 0.9rem; }
        .page-title {
            font-size: 1.7rem; font-weight: 800; margin-bottom: 0.2rem; color: #0b3b4a;
            border-right: 6px solid #0f766e; padding-right: 12px;
        }
        .page-sub { color: #55646f; margin-bottom: 1rem; padding-right: 18px; }
        div[data-testid="stDataFrame"], div[data-testid="stDataFrame"] * { direction: ltr !important; }
        button[data-baseweb="tab"] { font-weight: 600; }
        </style>
        """.replace("__BG__", _background_css()),
        unsafe_allow_html=True,
    )


def page_header(title: str, subtitle: str = ""):
    st.markdown(f"<div class='page-title'>{title}</div>", unsafe_allow_html=True)
    if subtitle:
        st.markdown(f"<div class='page-sub'>{subtitle}</div>", unsafe_allow_html=True)



# ---------------------------------------------------------------- save UX helpers
_UNIQUE_MSG = {
    "companies.name": "يوجد شركة بهذا الاسم مسجلة مسبقاً.",
    "employees.national_id": "رقم الهوية هذا مسجل مسبقاً لموظف آخر.",
}


def flash_set(msg: str, ver_key: str = None):
    """Remember a success message across the rerun that follows a save, and reset the form's fields."""
    st.session_state["_flash_ok"] = msg
    if ver_key:
        st.session_state[ver_key] = st.session_state.get(ver_key, 0) + 1


def show_flash():
    msg = st.session_state.pop("_flash_ok", None)
    if msg:
        st.toast(msg, icon="✅")


def form_ver(ver_key: str) -> int:
    return st.session_state.get(ver_key, 0)


def friendly_error(e, prefix: str = "تعذر الحفظ") -> str:
    text = str(e)
    if text.startswith("UNIQUE constraint failed:"):
        key = text.split(":", 1)[1].strip()
        return _UNIQUE_MSG.get(key, "يوجد سجل مطابق مسجل مسبقاً (قيمة يجب ألا تتكرر).")
    return f"{prefix}: {text}" if text else prefix


def duplicate_of(table: str, name: str, phone: str, name_col: str = "name"):
    """id of an existing row with the same name and phone (blank phones compare equal), else None."""
    from db import query_all
    n = " ".join((name or "").split()).lower()
    p = (phone or "").strip()
    for r in query_all(f"SELECT id, {name_col} AS name, phone FROM {table}"):
        if " ".join((r["name"] or "").split()).lower() == n and (r["phone"] or "").strip() == p:
            return r["id"]
    return None


def toast_flash(key: str):
    """Show (once) a success message stored in session_state[key], as a toast so the layout does not move."""
    msg = st.session_state.pop(key, None)
    if msg:
        st.toast(msg, icon="✅")


# ---------------------------------------------------------------- navigation
NAV_GROUPS = [
    ("الرئيسية", "🏠", ["لوحة التحكم", "المساعد"]),
    ("البيانات الأساسية", "🗂️", ["ملف الجهة", "الشركات والموظفون", "المتعهدون", "المندوبون"]),
    ("العمليات", "🔗", ["العقود", "الوثائق"]),
    ("المالية", "💰", ["التحويلات والحساب الشهري", "مراجعة وإقفال الشهر",
                       "التحصيل والمدفوعات", "كشوف الحسابات", "السندات", "فواتير العملاء", "التقارير المالية والإدارية"]),
    ("النظام", "⚙️", ["النسخ الاحتياطي والاستعادة", "سجل التدقيق", "الإعدادات", "حسابي والمستخدمون"]),
]


def set_page(page: str):
    st.session_state["_page"] = page


def sidebar_nav(allowed: list) -> str:
    """Grouped, collapsible menu. Returns the current page (always one of `allowed`)."""
    cur = st.session_state.get("_page")
    if cur not in allowed:
        cur = allowed[0]
        st.session_state["_page"] = cur
    listed = set()

    def btn(p):
        st.button(p, key=f"nav_{p}", use_container_width=True,
                  type="primary" if p == cur else "secondary", on_click=set_page, args=(p,))

    for title, icon, pages in NAV_GROUPS:
        vis = [p for p in pages if p in allowed]
        listed.update(vis)
        if not vis:
            continue
        if len(vis) == 1:
            btn(vis[0])
        else:
            with st.expander(f"{icon} {title}", expanded=cur in vis):
                for p in vis:
                    btn(p)
    rest = [p for p in allowed if p not in listed]
    if rest:
        with st.expander("أخرى", expanded=cur in rest):
            for p in rest:
                btn(p)
    return cur


def goto_button(label: str, page: str, key: str):
    """A shortcut button that jumps to another page (callers check the user may open it)."""
    st.button(label, key=key, use_container_width=True, on_click=set_page, args=(page,))


# ------------------------------------------------------------ selectable tables
def tver(name: str) -> int:
    return st.session_state.get(f"_tv_{name}", 0)


def tbump(name: str):
    st.session_state[f"_tv_{name}"] = tver(name) + 1


def select_table(df, name: str):
    """Shows a table whose rows can be clicked; returns the selected row position or None.
    tbump(name) clears the selection."""
    try:
        cfg = {c: st.column_config.Column(alignment="right") for c in df.columns}
    except TypeError:                      # older Streamlit without column alignment
        cfg = None
    ev = st.dataframe(df.fillna(""), use_container_width=True, hide_index=True, on_select="rerun",
                      selection_mode="single-row", column_config=cfg, key=f"_tbl_{name}_{tver(name)}")
    rows = ev.selection.rows if ev is not None else []
    return rows[0] if rows else None


def excel_button(df, filename: str, key: str, label: str = "⬇️ تصدير Excel"):
    """Download button for the table currently shown (exactly the rows/columns on screen)."""
    import io
    out = io.BytesIO()
    with pd.ExcelWriter(out, engine="openpyxl") as w:
        df.to_excel(w, index=False, sheet_name="البيانات")
    st.download_button(label, out.getvalue(), file_name=f"{filename}.xlsx", key=key,
                       mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")


_DIGITS = str.maketrans("٠١٢٣٤٥٦٧٨٩۰۱۲۳۴۵۶۷۸۹٬٫،", "01234567890123456789,.,")


MONTH_EXAMPLE = "\u20662026-03\u2069"   # shown left-to-right even inside Arabic text


def norm_month(text):
    """'2026-10', '10-2026', '2026/10', Arabic digits -> '2026-10'. None if it is not a month."""
    import re as _re
    t = (text or "").strip().translate(_DIGITS).replace("/", "-").replace("\\", "-").replace(".", "-").replace(" ", "")
    m = _re.fullmatch(r"(\d{4})-(\d{1,2})", t)
    if m:
        y, mo = m.group(1), int(m.group(2))
    else:
        m = _re.fullmatch(r"(\d{1,2})-(\d{4})", t)
        if not m:
            return None
        mo, y = int(m.group(1)), m.group(2)
    return f"{y}-{mo:02d}" if 1 <= mo <= 12 else None


def parse_number(text):
    """'1,500.50' / '١٥٠٠' / '1500' -> float. Empty -> None. Raises ValueError with an Arabic message."""
    t = str(text or "").translate(_DIGITS).replace(",", "").replace(" ", "").strip()
    if not t:
        return None
    try:
        n = float(t)
    except ValueError:
        raise ValueError("اكتب رقماً صحيحاً (أرقام فقط).")
    if n != n or n in (float("inf"), float("-inf")):
        raise ValueError("اكتب رقماً صحيحاً (أرقام فقط).")
    return n


def number_field(label, key, value=None, placeholder="0.00", integer=False, minimum=None, maximum=None, help=None):
    """Typed number box. (Streamlit's number_input mangles typing in right-to-left pages: '1500' becomes '0.001500'.)
    Returns a float/int, or None when empty or invalid (an inline message explains the problem)."""
    shown = "" if value in (None, "") else (str(int(value)) if integer else f"{float(value):g}")
    raw = st.text_input(label, value=shown, key=key, placeholder=placeholder, help=help)
    try:
        n = parse_number(raw)
    except ValueError as e:
        st.caption(f"⚠️ {e}")
        return None
    if n is None:
        return None
    if integer and n != int(n):
        st.caption("⚠️ اكتب عدداً صحيحاً.")
        return None
    if minimum is not None and n < minimum:
        st.caption(f"⚠️ الحد الأدنى {minimum:g}.")
        return None
    if maximum is not None and n > maximum:
        st.caption(f"⚠️ الحد الأقصى {maximum:g}.")
        return None
    return int(n) if integer else n
