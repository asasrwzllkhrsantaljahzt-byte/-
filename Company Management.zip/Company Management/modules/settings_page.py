import streamlit as st
import security
import app_settings
import branding
from ui import toast_flash, number_field


def render():
    user = security.current_user()
    if not user or user["role"] != "admin":
        st.error("الإعدادات متاحة لمدير النظام فقط.")
        return
    toast_flash("_set_flash")
    cur = app_settings.get_all()
    with st.form("settings_form"):
        st.markdown("**بيانات المنشأة** (يظهر الاسم في القائمة الجانبية)")
        org_name = st.text_input("اسم المنشأة *", value=cur["org_name"], key="set_org_name")
        c1, c2 = st.columns(2)
        with c1:
            cr = st.text_input("السجل التجاري", value=cur["org_commercial_register"], key="set_cr")
            phone = st.text_input("الهاتف", value=cur["org_phone"], key="set_phone")
        with c2:
            tax = st.text_input("الرقم الضريبي", value=cur["org_tax_number"], key="set_tax")
            addr = st.text_input("العنوان", value=cur["org_address"], key="set_addr")
        st.markdown("**التنبيهات**")
        d1, d2, d3 = st.columns(3)
        with d1:
            alert_days = number_field("تنبيه انتهاء العقود قبل (يوماً)", "set_alert_days", value=int(app_settings.get_int("contract_alert_days")), integer=True) or 0
        with d2:
            bk_days = number_field("تذكير النسخ الاحتياطي بعد (يوماً)", "set_bk_days", value=int(app_settings.get_int("backup_reminder_days")), integer=True) or 0
        with d3:
            doc_days = number_field("تنبيه انتهاء الوثائق قبل (يوماً)", "set_doc_days", value=int(app_settings.get_int("doc_alert_days")), integer=True) or 0
        d4, _x, _y = st.columns(3)
        with d4:
            dues_days = number_field("تنبيه المستحقات غير المسددة بعد (يوماً من نهاية الشهر)", "set_dues_days", value=int(app_settings.get_int("dues_alert_days")), integer=True) or 0
        st.markdown("**الفواتير**")
        vat = number_field("نسبة ضريبة القيمة المضافة (%)", "set_vat", value=int(app_settings.get_int("vat_rate")), integer=True) or 0
        sub = st.form_submit_button("حفظ الإعدادات", type="primary")
    if sub:
        try:
            changed = app_settings.save({
                "org_name": org_name, "org_commercial_register": cr, "org_tax_number": tax,
                "org_phone": phone, "org_address": addr,
                "contract_alert_days": int(alert_days), "backup_reminder_days": int(bk_days), "doc_alert_days": int(doc_days), "dues_alert_days": int(dues_days), "vat_rate": int(vat)})
            st.session_state["_set_flash"] = "تم حفظ الإعدادات." if changed else "لا توجد تغييرات."
            st.rerun()
        except ValueError as ex:
            st.error(str(ex))

    st.markdown("---")
    st.markdown("**الشعار** (يظهر في القائمة وشاشة الدخول والمطبوعات)")
    lp = branding.logo_path()
    c1, c2 = st.columns([1, 3])
    if lp:
        c1.image(lp, width=110)
    up = c2.file_uploader("رفع شعار جديد (PNG أو JPG)", type=["png", "jpg", "jpeg"], key="set_logo")
    if up is not None and isinstance(up.getvalue(), bytes) and c2.button("حفظ الشعار", key="set_logo_go"):
        try:
            st.session_state["_set_flash"] = branding.save_logo(up.getvalue())
            st.rerun()
        except ValueError as ex:
            st.error(str(ex))
